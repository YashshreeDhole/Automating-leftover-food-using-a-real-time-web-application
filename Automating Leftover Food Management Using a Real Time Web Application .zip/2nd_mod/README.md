# Food Donation Web Application

## Overview

This Flask web application is designed to facilitate food donation, allowing users to contribute to the community by providing surplus food to those in need. The application features a simple and intuitive user interface for both donors and recipients.

## Features

- **Donor Registration:** Donors can sign up by providing their details, including full name, email, phone number, and address.

- **Donation Form:** Donors can submit details about the quantity of food, its freshness, and the time since it was prepared.

- **Admin Panel:** Admin users have access to view and manage all donation data, ensuring efficient coordination and monitoring.

## Technologies Used

- Flask: A lightweight and powerful web framework for Python.
- SQLite: A simple and reliable database system.
- HTML/CSS: Used for frontend design and styling.
- Bootstrap: A front-end framework for responsive and mobile-first web development.

## Setup Instructions

1. Clone the repository:

    ```bash
    git clone https://github.com/yourusername/food-donation-app.git
    cd food-donation-app
    ```

2. Create a virtual environment:

    ```bash
    python -m venv venv
    ```

3. Activate the virtual environment:

    - On Windows:

        ```bash
        venv\Scripts\activate
        ```

    - On Unix or MacOS:

        ```bash
        source venv/bin/activate
        ```

4. Install dependencies:

    ```bash
    pip install -r requirements.txt
    ```

5. Run the application:

    ```bash
    flask run
    ```

6. Access the application in your browser at [http://localhost:5000/](http://localhost:5000/).

## Usage

- **Donor Registration:**
  - Navigate to the registration page.
  - Provide your details and submit the form.

- **Donation:**
  - Log in with your credentials.
  - Fill out the donation form, providing information about the food quantity, freshness, and preparation time.

- **Admin Panel:**
  - Access the admin panel by logging in with the admin credentials.
  - View and manage all donation data.

## Screenshots

![Screenshot 1](screenshots/screenshot1.png)
![Screenshot 2](screenshots/screenshot2.png)

## Contribution Guidelines

Contributions are welcome! If you would like to contribute to the project, please follow the guidelines outlined in [CONTRIBUTING.md](CONTRIBUTING.md).

## License

This project is licensed under the [MIT License](LICENSE).
