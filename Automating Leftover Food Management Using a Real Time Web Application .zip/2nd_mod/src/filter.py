from datetime import datetime

#define time formate
def timeformat(value, format='%Y-%m-%d %H:%M:%S'):
    """Custom filter to format datetime."""
    return datetime.strptime(value, format).strftime('%H:%M')

# Define the date format filter
def dateformat(value, format='%Y-%m-%d %H:%M:%S'):
    """Custom filter to format datetime."""
    return datetime.strptime(value, format).strftime('%d-%m-%Y')
