from flask import Flask, render_template, request, redirect, url_for, session
from flask import g  # Add this import at the top
import sqlite3

from flask_login import UserMixin

# SQLite configuration
# DATABASE = 'database.db'
# DATABASE2 = 'donation_data.db'

# Function to check if user is logged in
def is_logged_in():
    return 'logged_in' in session


# Function to connect to the SQLite database
def get_db():
    db = sqlite3.connect('database.db')
    db.row_factory = sqlite3.Row
    return db

# Function to get the current user's email
def get_user_email():
    if is_logged_in():
        with get_db() as db:
            cur = db.cursor()
            username = session['username']
            result = cur.execute("SELECT email FROM users WHERE username = ?", [username])
            user = result.fetchone()
            return user['email'] if user else None
    return None

def get_all_data():
    conn = sqlite3.connect('donation_data.db')  # Replace 'your_database.db' with your actual database file
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM donations ORDER BY id DESC')
    alldata = cursor.fetchall()
    conn.close()
    return alldata

# Mockup user class, replace it with your user model
class User(UserMixin):
    def __init__(self, user_id):
        self.id = user_id