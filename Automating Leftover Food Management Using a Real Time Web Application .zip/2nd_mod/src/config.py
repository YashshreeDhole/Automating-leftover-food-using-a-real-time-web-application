# config.py

MYSQL_CONFIG = {
    'MYSQL_HOST': 'your_mysql_host',
    'MYSQL_USER': 'your_mysql_user',
    'MYSQL_PASSWORD': 'your_mysql_password',
    'MYSQL_DB': 'your_mysql_database',
}

users = {'admin': {'password': 'admin'}, 'sana': {'password': 'pass'}}

