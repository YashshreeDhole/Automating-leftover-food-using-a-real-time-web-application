import sqlite3
from datetime import datetime

def db1():
    conn = sqlite3.connect('contact_us.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            telephone TEXT NOT NULL,
            message TEXT NOT NULL,
            collab TEXT CHECK(collab IN ('true', 'false')) NOT NULL,
            message_datetime TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()
#---------------------------------------------------------------------------
    
def db1_1():
    conn = sqlite3.connect('NGO_contact.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            telephone TEXT NOT NULL,
            message TEXT NOT NULL,
            reg_no TEXT NOT NULL,
            So_link TEXT NOT NULL,
            collab TEXT CHECK(collab IN ('true', 'false')) NOT NULL,
            message_datetime TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

# --------------------------------------------------------------------------
def db2():
    conn = sqlite3.connect('donation_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS donations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            Full_name TEXT,
            email TEXT,
            Phone TEXT,
            quality TEXT,
            quantity TEXT,
            Address TEXT,
            city TEXT,
            donation_datetime TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

# -----------------------------------------------------------------------
def db3():
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            email TEXT NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    connection.commit()
    connection.close()
# -------------------------------------------------------------------------

db1()
db1_1()
# db2()
#db3()
