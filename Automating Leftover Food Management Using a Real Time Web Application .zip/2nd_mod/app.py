from flask import Flask, flash, render_template, request, redirect, url_for, session
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from src.config import users
from src.auth import *
from src.filter import*


app = Flask(__name__)

# Set a secret key for session management
app.secret_key = 'lkjhgfdsapoiuytrewcft'

login_manager = LoginManager(app)
login_manager.login_view = 'login'


# Register the filter to Jinja2 environment for DATE formate
app.jinja_env.filters['dateformat'] = dateformat


# Register the filter to Jinja2 environment for Time Formate
app.jinja_env.filters['timeformat'] = timeformat


@app.route('/c')
def c():
    # Replace 'path/to/index.html' with the actual path to your HTML file
    return render_template('/c.html')

@app.route('/')
def index():
    # Replace 'path/to/index.html' with the actual path to your HTML file
    return render_template('/index.html')

@app.route('/about')
def about():
    # Replace 'path/to/about.html' with the actual path to your HTML file
    return render_template('/about.html')

@app.route('/services')
def services():
    # Replace 'path/to/services.html' with the actual path to your HTML file
    return render_template('/services.html')

@app.route('/contact')
def contact():
    # Replace 'path/to/contact.html' with the actual path to your HTML file
    return render_template('/contact.html')

@app.route('/auth')
def auth():
    # Replace 'path/to/login.html' with the actual path to your HTML file
    return render_template('/login.html')

@app.route('/donor')
def donor():
    if is_logged_in():
        username = session['username']
        email = get_user_email()

        # Pass the email to the template
        return render_template('donor.html', username=username, email=email)
    else:
        return redirect(url_for('auth'))
    #return render_template("/donor.html")


# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get form data
        username = request.form['username']
        password_candidate = request.form['password']

        # Connect to the SQLite database
        db = get_db()
        cur = db.cursor()

        # Fetch user by username
        result = cur.execute("SELECT * FROM users WHERE username = ?", [username])

        user = result.fetchone()

        if user is not None:
            # Get stored password
            stored_password = user['password']

            # Compare passwords (in plain text)
            if password_candidate == stored_password:
                # Passwords match, set session variables
                session['logged_in'] = True
                session['username'] = username

                # Close database connection
                db.close()

                return redirect(url_for('donor'))
            else:
                # Passwords do not match
                error = 'Invalid login'
                db.close()
                return render_template('login.html', error=error)
        else:
            # User not found
            error = 'Username not found'
            db.close()
            return render_template('login.html', error=error)

    return render_template('login.html')

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Get form data
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Connect to the SQLite database
        db = get_db()
        cur = db.cursor()

        # Execute query to insert user data into the 'users' table
        cur.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", (username, email, password))

        # Commit the changes
        db.commit()

        # Close database connection
        db.close()

        return redirect(url_for('auth'))

    return redirect(url_for('auth'))


@app.route('/donation', methods=['POST'])
def donation():
    if request.method == 'POST':
        full_name = request.form['Full_name']
        email = request.form['email']
        phone = request.form['Phone']
        quality = request.form['quality']
        quantity = request.form['quantity']
        address = request.form['Address']
        city = request.form['city']

        # Insert data into the database
        conn = sqlite3.connect('donation_data.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO donations (Full_name, email, Phone, quality, quantity,Address, city)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (full_name, email, phone, quality, quantity,address, city))
        conn.commit()
        conn.close()
        return render_template('thanks.html', data = 'so much for your donation')
    
    
    flash('Data not submitted. Please try again.')
    return redirect(url_for('donor'))
    
        #collab = request.form['collab']  # Add collab from form


@app.route('/contact_us', methods=['GET', 'POST'])
def contact_us():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        telephone = request.form['telephone']
        message = request.form['message']
        user_type = request.form['user_type'] 
        #for NGO
        registration = request.form['registration']
        Link = request.form['Link']
        
        #print(request.form['collab'])
        
        if 'collab' in request.form:
            collab = "true"
        else:
            collab = "false"

        print(collab)
        
        if user_type == 'NGO':
            conn = sqlite3.connect('NGO_contact.db')
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO contacts (name, email, telephone, message, reg_no, So_link, collab) 
                VALUES (?, ?, ?, ?, ?, ?,?)''',
                (name, email, telephone, message, registration, Link , collab))
            conn.commit()
            conn.close()

            flash('NGO Feedback submitted successfully!', 'success')
        
        elif user_type == 'DONOR':
            conn = sqlite3.connect('contact_us.db')
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO contacts (name, email, telephone, message, collab) 
                VALUES (?, ?, ?, ?, ?)''',
                (name, email, telephone, message, collab))
            conn.commit()
            conn.close()

            flash('DONOR Feedback submitted successfully!', 'success')
        # Store data in SQLite database

    return render_template('thanks.html', data = 'For contacting us')


# Mockup user database, replace it with your user database
# users = {'admin': {'password': 'admin'}, 'sana': {'password': 'pass'}}

@login_manager.user_loader
def load_user(user_id):
    return User(user_id)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users.get(username)

        if user and password == user['password']:
            user_obj = User(username)
            login_user(user_obj)
            flash('Login successful!', 'success')
            return redirect(url_for('alldata'))
        else:
            flash('Invalid username or password', 'danger')

    return render_template('admin.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logout successful!', 'success')
    return redirect(url_for('admin'))


@app.route('/alldata')
@login_required
def alldata():
    alldata = get_all_data()
    # print('printing data')
    # print(alldata)
    return render_template('alldata.html', alldata=alldata)

@app.route('/view_msg')
@login_required
def view_msg():
    conn = sqlite3.connect('contact_us.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM contacts ORDER BY id DESC')
    data = cursor.fetchall()
    conn.close()

    return render_template('view_data.html', data=data)

@app.route('/data_ngo')
@login_required
def feed():
    conn = sqlite3.connect('NGO_contact.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM contacts ORDER BY id DESC')
    data = cursor.fetchall()
    conn.close()
    print(data)
    return render_template('ngo_data.html', data=data)


if __name__ == '__main__':
    app.run(debug=True)
