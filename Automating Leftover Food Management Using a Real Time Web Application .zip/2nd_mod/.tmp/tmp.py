from flask import Flask, flash, render_template, request, redirect, url_for, session
import bcrypt
import sqlite3
from src.config import MYSQL_CONFIG
from src.auth import *

app = Flask(__name__)

# SQLite configuration
# DATABASE = 'database.db'
# DATABASE2 = 'donation_data.db'

# Set a secret key for session management
app.secret_key = 'qwertyuioplkjhgfdsa'


@app.route('/')
def index():
    # Replace 'path/to/index.html' with the actual path to your HTML file
    return render_template('/login.html')

@app.route('/auth')
def auth():
    # Replace 'path/to/index.html' with the actual path to your HTML file
    return render_template('/login.html')

@app.route('/donor')
def donor():
    if is_logged_in():
        username = session['username']
        email = get_user_email()

        # Pass the email to the template
        return render_template('donor.html', username=username, email=email)
    else:
        return redirect(url_for('auth'))
    #return render_template("/donor.html")


# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get form data
        username = request.form['username']
        password_candidate = request.form['password']

        # Connect to the SQLite database
        db = get_db()
        cur = db.cursor()

        # Fetch user by username
        result = cur.execute("SELECT * FROM users WHERE username = ?", [username])

        user = result.fetchone()

        if user is not None:
            # Get stored password
            stored_password = user['password']

            # Compare passwords (in plain text)
            if password_candidate == stored_password:
                # Passwords match, set session variables
                session['logged_in'] = True
                session['username'] = username

                # Close database connection
                db.close()

                return redirect(url_for('donor'))
            else:
                # Passwords do not match
                error = 'Invalid login'
                db.close()
                return render_template('login.html', error=error)
        else:
            # User not found
            error = 'Username not found'
            db.close()
            return render_template('login.html', error=error)

    return render_template('login.html')

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Get form data
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Connect to the SQLite database
        db = get_db()
        cur = db.cursor()

        # Execute query to insert user data into the 'users' table
        cur.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", (username, email, password))

        # Commit the changes
        db.commit()

        # Close database connection
        db.close()

        return redirect(url_for('auth'))

    return redirect(url_for('auth'))


@app.route('/donation', methods=['POST'])
def donation():
    if request.method == 'POST':
        full_name = request.form['Full_name']
        email = request.form['email']
        phone = request.form['Phone']
        food_quantity = request.form['food_quantity']
        address = request.form['Address']
        city = request.form['city']

        # Insert data into the database
        conn = sqlite3.connect('donation_data.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO donations (Full_name, email, Phone, food_quantity, Address, city)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (full_name, email, phone, food_quantity, address, city))
        conn.commit()
        conn.close()
        return render_template('thanks.html')
    
    flash('Data not submitted. Please try again.')
    return redirect(url_for('donor'))
    

if __name__ == '__main__':
    app.run(debug=True)
